
/*
    
    Name:Shrishti Kumari
    Registration no: 201900131
    
    Description: To demonstrate a program to make class name Employee and to read certain information and display it.
    
               Input Variables:Name,Employee_code,Gross_salary
               Output Variables:Name,Employee_code,Gross_salary

                 n: size
*/

#include<iostream>//Header file
#include<string>

using namespace std;

//Class name
class Employee
{
    private://Access specifier
    
      //Data members
       string  Name;
       int Employee_code;
       float Gross_salary;
       
    public://Access specifiers
    
      //Member function
        void read();//To read certain info
        void display();//To display info that were asked
        
};

//Defining member function  to read info that were asked
void Employee::read()
{	 	  	 	  	 	   	        	 	
    cout<<"Employee code: ";
    cin>>Employee_code;//Reading employee code
    
    
    cout<<"Name: ";
    cin>>Name;//Reading name
    
    cout<<"Gross Salary: ";
    cin>>Gross_salary;//Reading gross salary
    
}

//Defining member function to display all the info that were asked
void Employee::display()
{
    cout<<"Name: "<<Name<<endl;//Displaying name
    cout<<"Employee code: "<<Employee_code<<endl;//Displaying employee code
    cout<<"Gross salary: "<<Gross_salary<<endl;//Displaying gross salary
}

//main function
int main()
{
    Employee E[10];//Class
    int i,n=10;//Declaring and initializing
    
    cout<<"ENTER 10 EMPLOYEES INFORMATION:"<<endl;
    
    //By using array we read the info of 10 employees 
    for(i=0;i<n;i++)
    {
        cout<<"Employee  "<<i+1<<":"<<endl;//i+1 is used because we initialize i=0
        E[i].read();//Calling to read  the certain info
        
        cout<<"\n********************************"<<endl;//Given to find diffeernces in dispaly and reading
        cout<<"\nInfo of employee "<<i+1<<":"<<endl;
        E[i].display();//Calling to display all the member function
        
        cout<<"\n--------------------------------------------------------------"<<endl;//Given to read different student info
    }	 	  	 	  	 	   	        	 	
    
    return 0;//As return type is int
}