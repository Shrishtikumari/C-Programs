/*
 Name:Shrishti Kumari
 Registration no:201900131
 Description: To demonstrate a program to implement a class called Bank and include the following data members:- a. Name of account holder b. Account number 
              c. type of account d. balance amount in account e. number of transactions in the bank(static data member)  and perform compile time operations.
    
    Algorithm:
         
           Algorithm description: this algorithm is all about how we implement a class called Bank and include the following data members:- a. Name of account holder b. Account number 
                                  c. type of account d. balance amount in account e. number of transactions in the bank(static data member)  and perform compile time operations and
                                   transactions.
           Input variables:choice,t
           Output Variables:functions were giving outputs.
    1.Start
    2.Create a class of name Bank with following data members and member function and perform operations.
    3.In main function
    4.Display "DISPLAYING 2 ACCOUNT HOLDER INFO USING DATA MEMBER TRANSACTION AS STATIC"
    5.Display "***********************ACCOUNT HOLDER ONE DETAILS***********************"
    6.Making a object of class Bank and initializing it which will call parameterized constructor automatically.
    7.Bank B1("Shrishti Kumari",4567810,"Savings",50000)
      7.1 holder_name=Name
      7.2 account_no=Acc_no
      7.3 account_type=Acc_type
      7.4 balance=Bal
    8.Calling display function to show all the data members values and to perform operations that were asked in it.
    9. B1.display()
   10. Calling function to perform transactions according to users choice.
   11. B1.CASE()
      11.1 Declare t,choice,wid,dep,s
      11.2 while(1)
         11.2.1 Display "-------------------------------------------------------------------------"
         11.2.2 Display "Want to do transaction, if yes press 1 if not then press 0:"
         11.2.3 Read t
         11.2.4 Check if(t==0) then return 1 otherwise go to step 11.2.3
         11.2.5 Display "MENU:"
         11.2.6 Display "1.Withdraw"
         11.2.7 Display "2.Deposit"
         11.2.8 Display "Other options will make you exit from transaction part."
         11.2.9 Display "Enter your choice:"
         11.2.10 Read choice
         11.2.11 Constructing switch case to perform according users demand 
         11.2.12 switch(choice)
           11.2.12.1 
             case 1:
                 1.1 Display "Enter amount of money do want to withdraw:"
                 1.2 Read wid
                 1.3 s=withdraw(wid) calling to perform all the withdrawing  operations that were asked in it.
                 1.4 Display balance
                 1.5 break
           case 2:
                 2.1 Display "Enter amount of money you want to deposit:"
                 2.2 Read dep
                 2.3 s=deposit(dep) calling to perform all the depositing  operations that were asked in it.
                 2.4 Display balance
                 2.5 break

           default:
                 return 1
   12.B1.display_transaction_history() displaying static member function operation
   13.Display "***********************ACCOUNT HOLDER SECOND DETAILS********************"
   14.Making a object of class Bank and initializing it which will call parameterized constructor automatically.
   15.Bank B2("Khushi Singh",5567810,"Savings",60000)
   16.B2.display() calling to display
   17.Display "##As you can see that no of transactions at starting of account holder 2 = no of transaction done in holder 1."
   18.B2.CASE() calling to work on transaction operation according to users choice.
   19 B2.display_transaction_history()
   20.Display "**************************************************************************"
   21 Display "As You Can See that no of transactions at end =no of transactions of holder 1 + no of transaction holder 2."
   22.Display "So, we can see from this that transaction is static in this case."
   23.Display "------------------------------------------------------------------------------------------------"
   24.Stop
    
*/
           
#include<iostream>//Header file
using namespace std;

//Creating class of name Bank
class Bank
{	 	  	 	  	 	   	        	 	
  private://Access specifier
  
     //Data members
         string holder_name;
         int account_no;
         string account_type;
         int balance;
         
  public://Access specifier
  
    //Member function
         static int transaction;
         double deposit(int a);
         double withdraw(int a);
         Bank(string Name,int Account_no,string Account_type,int Balance);
         void display();
         int CASE();
         static int display_transaction_history();
};

int Bank::transaction=0;

//Defing parameterized constructor
Bank::Bank(string Name,int Acc_no,string Acc_type,int Bal)
{
    //computing
  holder_name=Name;
  account_no=Acc_no;
  account_type=Acc_type;
  balance=Bal;
}

//Displaying member function to display all the data members
void Bank::display()
{
    cout<<"Name of account holder:"<<holder_name<<endl;
    cout<<"Account no: "<<account_no<<endl;
    cout<<"Account type:"<<account_type<<endl;
    cout<<"Balance:"<<balance<<endl;
    cout<<"No of transactions :"<<transaction<<endl;
}	 	  	 	  	 	   	        	 	

//Definning member function to Perform depositing operation
double Bank::deposit(int a)
{
    balance=balance+a;
    transaction++;//incrementing
    return balance;//returning
}

//Definning member function to Perform withdrawn operation
double Bank::withdraw(int a)
{
    if(balance<a)//if it is more than available balance
    {
        cout<<"Fund is insufficient to withdraw.\n";
        return balance;
    }
    else
    {
        balance-=a;
        transaction++;//incrementing
        return balance;//returning
    }
}

//Definning member function to perform all the transaction operations
int Bank::CASE()
{
    int t,choice,wid,dep,s;//Declared
    
    //checking
    while(1)
    {
        cout<<"\n-------------------------------------------------------------------------\n";
        cout<<"Want to do transaction, if yes press 1 if not then press 0:";
        cin>>t;//Reading t
        if(t==0)
        {	 	  	 	  	 	   	        	 	
            return 1;//if user doesn't want to do transaction
        }
        else
    
        {
            cout<<"\nMENU:\n";
            cout<<"1.Withdraw\n";
            cout<<"2.Deposit\n";
            cout<<"Other options will make you exit from transaction part.\n";
            cout<<"\nEnter your choice:";
            cin>>choice;//Reading
            
            //Constructing switch case to work according to users choice
            switch(choice)
            {
               case 1:
                     cout<<"Enter amount of money do want to withdraw:";
                     cin>>wid;
                     s=withdraw(wid);//Calling to perform withdrawn operations
                     cout<<"Available balance : "<<s<<endl;
                     break;//Terminating out of the loop
               case 2:
                     cout<<"Enter amount of money you want to deposit:";
                     cin>>dep;
                     s=deposit(dep);//Calling to perform depositing operations
                     cout<<"Available balance : "<<s<<endl;
                     break;//Terminating out of the loop

               default:
                     return 1;

            }
        }
    }
}

//Deffing static member function to display transaction
int Bank::display_transaction_history()
{	 	  	 	  	 	   	        	 	
    cout<<"No of transactions after:"<<transaction<<endl;
}

//main function
int main()
{
    cout<<"\nDISPLAYING 2 ACCOUNT HOLDER INFO USING DATA MEMBER TRANSACTION AS STATIC\n";
    
    cout<<"\n***********************ACCOUNT HOLDER ONE DETAILS***********************\n\n";
    Bank B1("Shrishti Kumari",4567810,"Savings",50000);//Declaring and initializing and this will automatically parameterized constructor
    B1.display();
    B1.CASE();//To perform transaction according to users choice
    B1.display_transaction_history();//To display

    cout<<"\n***********************ACCOUNT HOLDER SECOND DETAILS********************\n\n";
    Bank B2("Khushi Singh",5567810,"Savings",60000);//Declaring and initializing and this will automatically parameterized constructor
    B2.display();

    cout<<"\n##As you can see that no of transactions at starting of account holder 2 = no of transaction done in holder 1.\n";

    B2.CASE();//To perform transaction according to users choice
    B2.display_transaction_history();//To display

    cout<<"\n**************************************************************************\n\n";

    cout<<"As You Can See that no of transactions at end =no of transactions of holder 1 + no of transaction holder 2.\n";
    cout<<"\nSo, we can see from this that transaction is static in this case.\n";
    cout<<"----------------------------------------------------------------------------------\n";
    return 0;//As return type is int
}
	 	  	 	  	 	   	        	 	
