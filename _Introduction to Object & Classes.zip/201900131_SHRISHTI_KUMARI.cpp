
/*
      Program description=To find area of circle using OOPS.
      Name:Shrishti Kumari
      Registration no:201900131
      Date and Time:18/08/2020 and 11:15 AM
*/
#include<iostream>
using namespace std;

//Constructing class
class circle
{
    private://Access specifier
         float radius;
         const float pi=3.14;
         float area;
    
    public:
         void accept();
         void calculate();
         void display();
};

//APPLYING SCOPE RESOLUTION TO IMPLEMENT USER DEMAND
void circle::accept()
{
    cin>>radius;
    cout<<"Radius= "<<radius<<endl;
}

void circle::calculate()
{
    area=pi*radius*radius;
     
}

void circle::display()
{	 	  	 	  	 	   	        	 	
    cout<<"Area of circle= "<<area;
}

int main()
{
    circle c;
    
         cout<<"Enter a value for radius:\n";
         
    c.accept();//To read the radius
    c.calculate();//To calculate the area
    c.display();//To display the area of circle
    return 0;
}