
/*

  Name:Shrishti Kumari
  Registration no:201900131
  
  Description: To demonstrate a program to make a class name STUDENT and to find the average of two better marks for each student and display all the info that were asked. 
              
              Input Variables:USN,first_name,last_name,m1,m2,m3
              Output Variables:Avg_marks
              
*/

#include<iostream>//Header file
#include<string>
using namespace std;
 
 class STUDENT//Class name
 {
    private://Access specifiers
       
       //Data members
        int USN;
        string first_name,last_name,Name;
        float m1,m2,m3;
        float Avg_marks;
    
    public://Access specifiers
    
    //Member function
        void read();
        void avg_cal();
        void display();
 };
 
 //Defining member function read() to read the info of students
 void STUDENT::read()
 {	 	  	 	  	 	   	        	 	
     
     cout<<"\nUSN no:";
     cin>>USN;//Reading USN
     
             getline(cin,first_name);
             cout<<"First name:";
             getline(cin,first_name);//Reading first name
     
     cout<<"Last name:";
     getline(cin,last_name);//Reading last name
     
             cout<<"Marks in sub1:";
             cin>>m1;//Reading marks of sub1
     
     cout<<"Marks in sub2:";
     cin>>m2;//Reading marks of sub2
     
             cout<<"Marks in sub3:";
             cin>>m3;//Reading marks of sub3
 }
 
 //Defining member function to find average of two better marks
 void STUDENT::avg_cal()
 {
     //Checking the condition which will fulfill
     if((m1<m2) && (m1<m3))
     {
         Avg_marks=(m2+m3)/2;
     }
            
             else if(m2<m3)
             {
                 Avg_marks=(m1+m3)/2;
             }
     
     else
     {	 	  	 	  	 	   	        	 	
         Avg_marks=(m1+m2)/2;
     }
     
     Name= first_name +" "+ last_name;// Full name will be in this format
 }
 
 //Defining member function to display all the info of students that were asked before
 void STUDENT::display()
 {
     
     cout<<"Name: "<<Name<<endl;
     cout<<"USN: "<<USN<<endl;
     
         cout<<"MARKS IN SUB1: "<<m1<<endl;
         cout<<"MARKS IN SUB2: "<<m2<<endl;
     
     cout<<"MARKS IN SUB3: "<<m3<<endl;
     cout<<"Average of two better marks: "<<Avg_marks<<endl;
 }
 
 //Main function
int main()
{
    STUDENT s[10];//Class
    int i,n=10;//Declaring and initializing
    
    cout<<"Enter details of 10 students:\n";
    
    //Array used to find info of all the 10 students that were asked one by one
    for(i=0;i<n;i++)
    {
        cout<<"STUDENT  "<<i+1<<endl;//i+1 is given because we started the array at i=0
        s[i].read();//Calling to read the info
        
        s[i].avg_cal();//This member function will do calculation process
        cout<<"\n**************************************************\n";//This is given to find the difference in asked and displayed info
       
        cout<<"STUDENT  "<<i+1<<"  info:\n";
        s[i].display();//This member function will display all the info that were asked before
        cout<<"-------------------------------------------------------------------"<<endl;//This is given to find differences in student1 and other difference
    }	 	  	 	  	 	   	        	 	
    return 0;//As return type is int
}