/*  
      Program description:To demonstrate a program using structure and following measures should be taken
                         1. To  read  the  data  into  structure  members  using  a function. 
                         2. Create  a  function  named  validate()  to  validate  the  date  
                         3. Display  the  date  in  the  format  “April  29  2014”  using  a function
                    
      Name:Shrishti Kumari
      Registration no:201900131
      Date:18/08/2020 
      
*/

#include <iostream>

using namespace std;
//STRUCTING DATE
struct date
{
    int day;
    int month;
    int year;


}s;//Struct element

void read();
int validate();
void display();

int main()
{
    date s;
    cout<<"Enter following details:\n";
    read();//To read the info which is required
    validate();//To check data  whether it is correct or not
    display();//To display the corect output
    return 0;
}	 	  	 	  	 	   	        	 	

void read()//Reading info
{
    cout<<"Day:";
    cin>>s.day;
    cout<<"Month:";
    cin>>s.month;
    cout<<"Year:";
    cin>>s.year;
}

       
int validate()//Checking info
{
    if(s.year>=1950 && s.year<=3000)
    {
      if(s.month>=1 && s.month<=12)
      {
          if((s.day>=1 && s.day<=31) && (s.month==1 || s.month==3 || s.month==5 ||s.month==7 ||s.month==8 || s.month==10 ||s.month==12))
          {
              return 1;
          }
              else if((s.day>=1 && s.day<=30) && (s.month==4 || s.month==6 ||s.month==9 ||s.month ==11))
              {
                  return 1;
              }
                  else if((s.day>=1 && s.day<=28) &&(s.month==2))
                  {
                      return 1;
                  }
                      else if(s.day==29 && s.month==2 && (s.year%400==0 || (s.year%4==0 && s.year%100!=0)))
            
                      {
                          return 1;
                      }
                              else
                              {	 	  	 	  	 	   	        	 	
                                  return 0;
                              }

      }
      else
      {
        return 0;
      }
    }
    else
    {
        return 0;
    }

}
void display()//Displaying info
{
    if(validate()==0)
        cout<<"WRONG INPUT HAS BEEN TAKEN.";
    else
    {
        char month_name[12][15]={"January","February","March","April","May","June","July","August","September","October","November","December"};
        
        cout<<"Date: "<<month_name[s.month-1]<<" "<<s.day<<" "<<s.year;
    }
}
	 	  	 	  	 	   	        	 	
